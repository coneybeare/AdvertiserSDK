# android Download Attribution

1. Drop the 'src' folder to your local project
2. In your main application class, add this to the onCreate method:

'''java
Vungle.init(this);
'''
